#!/bin/sh
sudo ./install-k3s.sh \
  --tls-san 1.237.63.41 \
  --generate-kubeconfig \
  --kubeconfig-out ~/edge5.kubeconfig \
  --install-n8n \
  --n8n-host n8n.default.local \
  --n8n-iframe-allow "https://kadap-edge.quantum-x.co.kr"
