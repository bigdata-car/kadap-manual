#!/usr/bin/env bash
###############################################################################
# k3s Installation Script
#
# Description : Linux 기반 시스템에 k3s를 자동 설치하는 스크립트
# Usage       : wget -O install-k3s.sh <URL> && chmod +x install-k3s.sh
#               sudo ./install-k3s.sh [OPTIONS]
#
# Options     :
#   -v, --version <VERSION>   설치할 k3s 버전 (예: v1.30.5+k3s1). 미지정 시 stable
#   -m, --mode <server|agent> 노드 모드 (default: server)
#   -t, --token <TOKEN>       cluster join token (agent 모드 또는 HA 시 필수)
#   -u, --url <URL>           server URL (agent 모드 시 필수, 예: https://10.0.0.1:6443)
#   -d, --data-dir <PATH>     k3s 데이터 디렉토리 (default: /var/lib/rancher/k3s)
#   --disable <COMPONENTS>    비활성화할 컴포넌트 (예: traefik,servicelb)
#   --no-traefik              traefik 비활성화 (편의 옵션)
#   --tls-san <HOST>          API 서버 인증서 SAN 추가 (반복 지정 가능)
#                             미지정 시 호스트 1차 IP 자동 추가
#   --kubeconfig-mode <MODE>  kubeconfig 파일 권한 (default: 644)
#   --cluster-init            HA 클러스터의 첫 server 노드 초기화
#   --skip-firewall           방화벽 설정 단계 스킵
#
# kubeconfig (API 접근 제어용 - ServiceAccount 토큰 기반):
#   --generate-kubeconfig         외부 API 접근용 kubeconfig 파일 생성
#   --kubeconfig-out <PATH>       출력 파일 경로
#                                 (default: /root/kubeconfig-admin-token.yaml)
#   --kubeconfig-sa <NAME>        ServiceAccount 이름 (default: admin-token-user)
#   --kubeconfig-sa-namespace <NS> SA namespace (default: kube-system)
#   --kubeconfig-cluster-role <ROLE> 부여할 ClusterRole (default: cluster-admin)
#   --kubeconfig-cluster <NAME>   kubeconfig cluster 이름 (default: admin-cluster)
#   --kubeconfig-context <NAME>   context 이름 (default: admin-context)
#   --kubeconfig-user <NAME>      user 이름 (default: admin-user)
#   --kubeconfig-server <URL>     외부 접근용 API server URL
#                                 (default: 자동 감지 — TLS SAN의 첫 도메인 또는 노드 IP)
#   --kubeconfig-token-duration <DUR>  토큰 유효기간 (default: 999999h, 사실상 무기한)
#
# Telegraf (Helm chart):
#   --install-telegraf            influxdata/telegraf Helm 차트 설치
#   --telegraf-namespace <NS>     namespace (default: monitoring)
#   --telegraf-release <NAME>     Helm release 이름 (default: telegraf)
#   --telegraf-output <TYPE>      출력 타입: influxdb_v2 | http (default: influxdb_v2)
#
#   [influxdb_v2 output]
#   --influxdb-url <URL>          InfluxDB v2 URL (예: http://influxdb.local:8086)
#   --influxdb-token <TOKEN>      InfluxDB v2 API token
#   --influxdb-org <ORG>          InfluxDB v2 organization
#   --influxdb-bucket <BUCKET>    InfluxDB v2 bucket
#
#   [http output + OAuth2 client_credentials]
#   --http-url <URL>              HTTP 수집 엔드포인트 (필수)
#   --http-data-format <FMT>      data_format (default: influx)
#   --http-method <METHOD>        HTTP method (default: POST)
#   --http-timeout <DUR>          요청 타임아웃 (default: 10s)
#   --http-content-encoding <ENC> 인코딩 (예: gzip)
#   --oauth2-token-url <URL>      OAuth2 token endpoint (필수)
#   --oauth2-client-id <ID>       OAuth2 client_id (필수)
#   --oauth2-client-secret <SEC>  OAuth2 client_secret (필수)
#   --oauth2-scopes <S1,S2,...>   OAuth2 scopes (콤마 구분, 선택)
#   --oauth2-audience <AUD>       OAuth2 audience 파라미터 (선택)
#
# n8n (Helm chart, community.8gears.n8n):
#   --install-n8n                 n8n Helm 차트 설치
#   --n8n-namespace <NS>          namespace (default: n8n)
#   --n8n-release <NAME>          Helm release 이름 (default: n8n)
#   --n8n-port <PORT>             외부 노출 포트 (default: 31000)
#   --n8n-host <HOST>             n8n 호스트명 (Ingress + WEBHOOK_URL용, 필수)
#   --n8n-storage-size <SIZE>     SQLite PVC 크기 (default: 2Gi)
#   --n8n-storage-class <CLASS>   StorageClass (default: local-path)
#   --n8n-iframe-allow <ORIGINS>  iframe 임베드 허용 도메인 (콤마 구분)
#                                 예: https://app.example.com,https://portal.example.com
#                                 미지정 시 iframe 임베드 차단 유지
#   --n8n-insecure-cookie         HTTPS 임베드 환경에서 secure cookie 비활성화
#                                 (HTTP 사용 시에만 권장)
#
#   -h, --help                도움말 출력
###############################################################################

set -euo pipefail

# ----------------------------------------------------------------------------
# 색상 출력 헬퍼
# ----------------------------------------------------------------------------
readonly C_RED='\033[0;31m'
readonly C_GREEN='\033[0;32m'
readonly C_YELLOW='\033[0;33m'
readonly C_BLUE='\033[0;34m'
readonly C_RESET='\033[0m'

log_info()  { echo -e "${C_BLUE}[INFO]${C_RESET}  $*"; }
log_ok()    { echo -e "${C_GREEN}[ OK ]${C_RESET}  $*"; }
log_warn()  { echo -e "${C_YELLOW}[WARN]${C_RESET}  $*"; }
log_error() { echo -e "${C_RED}[FAIL]${C_RESET}  $*" >&2; }

# ----------------------------------------------------------------------------
# 기본값
# ----------------------------------------------------------------------------
K3S_VERSION=""
NODE_MODE="server"
JOIN_TOKEN=""
SERVER_URL=""
DATA_DIR="/var/lib/rancher/k3s"
DISABLE_COMPONENTS=""
CLUSTER_INIT="false"
SKIP_FIREWALL="false"
KUBECONFIG_MODE="644"
TLS_SANS=()

# kubeconfig 발급 (외부 API 접근용 - ServiceAccount 기반)
GENERATE_KUBECONFIG="false"
KUBECONFIG_OUT="/root/kubeconfig-admin-token.yaml"
KUBECONFIG_SA="admin-token-user"
KUBECONFIG_SA_NAMESPACE="kube-system"
KUBECONFIG_CLUSTER_ROLE="cluster-admin"
KUBECONFIG_CLUSTER_NAME="admin-cluster"
KUBECONFIG_CONTEXT_NAME="admin-context"
KUBECONFIG_USER_NAME="admin-user"
KUBECONFIG_SERVER_URL=""
KUBECONFIG_TOKEN_DURATION="999999h"

# Telegraf (Helm)
INSTALL_TELEGRAF="false"
TELEGRAF_NAMESPACE="monitoring"
TELEGRAF_RELEASE="telegraf"
TELEGRAF_OUTPUT="influxdb_v2"   # influxdb_v2 | http

# InfluxDB v2 output
INFLUXDB_URL=""
INFLUXDB_TOKEN=""
INFLUXDB_ORG=""
INFLUXDB_BUCKET=""

# HTTP output + OAuth2 (client_credentials)
HTTP_URL=""
HTTP_DATA_FORMAT="influx"
HTTP_METHOD="POST"
HTTP_TIMEOUT="10s"
HTTP_CONTENT_ENCODING=""
OAUTH2_TOKEN_URL=""
OAUTH2_CLIENT_ID=""
OAUTH2_CLIENT_SECRET=""
OAUTH2_SCOPES=""
OAUTH2_AUDIENCE=""

# n8n (Helm)
INSTALL_N8N="false"
N8N_NAMESPACE="n8n"
N8N_RELEASE="n8n"
N8N_PORT="31000"
N8N_HOST=""
N8N_STORAGE_SIZE="2Gi"
N8N_STORAGE_CLASS="local-path"
N8N_IFRAME_ALLOW=""
N8N_INSECURE_COOKIE="false"
N8N_MIDDLEWARE_READY="false"   # 런타임에 Middleware 적용 성공 시 true

# ----------------------------------------------------------------------------
# 도움말
# ----------------------------------------------------------------------------
usage() {
    sed -n '2,75p' "$0" | sed 's/^# \{0,1\}//'
    exit 0
}

# ----------------------------------------------------------------------------
# 인자 파싱
# ----------------------------------------------------------------------------
while [[ $# -gt 0 ]]; do
    case "$1" in
        -v|--version)       K3S_VERSION="$2"; shift 2 ;;
        -m|--mode)          NODE_MODE="$2"; shift 2 ;;
        -t|--token)         JOIN_TOKEN="$2"; shift 2 ;;
        -u|--url)           SERVER_URL="$2"; shift 2 ;;
        -d|--data-dir)      DATA_DIR="$2"; shift 2 ;;
        --disable)          DISABLE_COMPONENTS="$2"; shift 2 ;;
        --no-traefik)       DISABLE_COMPONENTS="${DISABLE_COMPONENTS:+$DISABLE_COMPONENTS,}traefik"; shift ;;
        --tls-san)          TLS_SANS+=("$2"); shift 2 ;;
        --kubeconfig-mode)  KUBECONFIG_MODE="$2"; shift 2 ;;
        --cluster-init)     CLUSTER_INIT="true"; shift ;;
        --skip-firewall)    SKIP_FIREWALL="true"; shift ;;
        --generate-kubeconfig)        GENERATE_KUBECONFIG="true"; shift ;;
        --kubeconfig-out)             KUBECONFIG_OUT="$2"; shift 2 ;;
        --kubeconfig-sa)              KUBECONFIG_SA="$2"; shift 2 ;;
        --kubeconfig-sa-namespace)    KUBECONFIG_SA_NAMESPACE="$2"; shift 2 ;;
        --kubeconfig-cluster-role)    KUBECONFIG_CLUSTER_ROLE="$2"; shift 2 ;;
        --kubeconfig-cluster)         KUBECONFIG_CLUSTER_NAME="$2"; shift 2 ;;
        --kubeconfig-context)         KUBECONFIG_CONTEXT_NAME="$2"; shift 2 ;;
        --kubeconfig-user)            KUBECONFIG_USER_NAME="$2"; shift 2 ;;
        --kubeconfig-server)          KUBECONFIG_SERVER_URL="$2"; shift 2 ;;
        --kubeconfig-token-duration)  KUBECONFIG_TOKEN_DURATION="$2"; shift 2 ;;
        --install-telegraf)     INSTALL_TELEGRAF="true"; shift ;;
        --telegraf-namespace)   TELEGRAF_NAMESPACE="$2"; shift 2 ;;
        --telegraf-release)     TELEGRAF_RELEASE="$2"; shift 2 ;;
        --telegraf-output)      TELEGRAF_OUTPUT="$2"; shift 2 ;;
        --influxdb-url)         INFLUXDB_URL="$2"; shift 2 ;;
        --influxdb-token)       INFLUXDB_TOKEN="$2"; shift 2 ;;
        --influxdb-org)         INFLUXDB_ORG="$2"; shift 2 ;;
        --influxdb-bucket)      INFLUXDB_BUCKET="$2"; shift 2 ;;
        --http-url)             HTTP_URL="$2"; shift 2 ;;
        --http-data-format)     HTTP_DATA_FORMAT="$2"; shift 2 ;;
        --http-method)          HTTP_METHOD="$2"; shift 2 ;;
        --http-timeout)         HTTP_TIMEOUT="$2"; shift 2 ;;
        --http-content-encoding) HTTP_CONTENT_ENCODING="$2"; shift 2 ;;
        --oauth2-token-url)     OAUTH2_TOKEN_URL="$2"; shift 2 ;;
        --oauth2-client-id)     OAUTH2_CLIENT_ID="$2"; shift 2 ;;
        --oauth2-client-secret) OAUTH2_CLIENT_SECRET="$2"; shift 2 ;;
        --oauth2-scopes)        OAUTH2_SCOPES="$2"; shift 2 ;;
        --oauth2-audience)      OAUTH2_AUDIENCE="$2"; shift 2 ;;
        --install-n8n)          INSTALL_N8N="true"; shift ;;
        --n8n-namespace)        N8N_NAMESPACE="$2"; shift 2 ;;
        --n8n-release)          N8N_RELEASE="$2"; shift 2 ;;
        --n8n-port)             N8N_PORT="$2"; shift 2 ;;
        --n8n-host)             N8N_HOST="$2"; shift 2 ;;
        --n8n-storage-size)     N8N_STORAGE_SIZE="$2"; shift 2 ;;
        --n8n-storage-class)    N8N_STORAGE_CLASS="$2"; shift 2 ;;
        --n8n-iframe-allow)     N8N_IFRAME_ALLOW="$2"; shift 2 ;;
        --n8n-insecure-cookie)  N8N_INSECURE_COOKIE="true"; shift ;;
        -h|--help)          usage ;;
        *) log_error "알 수 없는 옵션: $1"; usage ;;
    esac
done

# ----------------------------------------------------------------------------
# 사전 점검
# ----------------------------------------------------------------------------
preflight_checks() {
    log_info "사전 점검 시작..."

    # root 권한
    if [[ $EUID -ne 0 ]]; then
        log_error "root 권한으로 실행해야 합니다. (sudo 사용)"
        exit 1
    fi

    # OS 확인
    if [[ ! -f /etc/os-release ]]; then
        log_error "/etc/os-release를 찾을 수 없습니다. 지원되지 않는 OS입니다."
        exit 1
    fi
    # shellcheck disable=SC1091
    source /etc/os-release
    log_info "감지된 OS: ${PRETTY_NAME:-$NAME $VERSION}"

    # 아키텍처
    local arch
    arch=$(uname -m)
    case "$arch" in
        x86_64|amd64|aarch64|arm64) log_info "아키텍처: $arch" ;;
        *) log_error "지원되지 않는 아키텍처: $arch"; exit 1 ;;
    esac

    # 필수 명령어
    for cmd in curl systemctl; do
        if ! command -v "$cmd" >/dev/null 2>&1; then
            log_error "필수 명령어 누락: $cmd"
            exit 1
        fi
    done

    # agent 모드 인자 검증
    if [[ "$NODE_MODE" == "agent" ]]; then
        if [[ -z "$JOIN_TOKEN" || -z "$SERVER_URL" ]]; then
            log_error "agent 모드는 --token과 --url이 모두 필요합니다."
            exit 1
        fi
    fi

    # kubeconfig / telegraf 부가 기능은 server 모드 전용
    if [[ "$NODE_MODE" != "server" ]]; then
        if [[ "$GENERATE_KUBECONFIG" == "true" ]]; then
            log_error "--generate-kubeconfig는 server 모드에서만 사용 가능합니다."
            exit 1
        fi
        if [[ "$INSTALL_TELEGRAF" == "true" ]]; then
            log_error "--install-telegraf는 server 모드에서만 사용 가능합니다."
            exit 1
        fi
        if [[ "$INSTALL_N8N" == "true" ]]; then
            log_error "--install-n8n은 server 모드에서만 사용 가능합니다."
            exit 1
        fi
    fi

    # Traefik 비활성화 시 n8n Ingress 사용 불가 경고
    if [[ "$INSTALL_N8N" == "true" ]]; then
        if [[ ",$DISABLE_COMPONENTS," == *",traefik,"* ]]; then
            log_error "--install-n8n은 Traefik Ingress가 필요합니다. --no-traefik / --disable=traefik와 함께 사용할 수 없습니다."
            exit 1
        fi
        if [[ -z "$N8N_HOST" ]]; then
            log_error "n8n 설치에는 --n8n-host가 필요합니다 (예: n8n.example.com)."
            exit 1
        fi
        # 포트 범위 점검 (k3s 기본 NodePort 범위는 30000-32767이나, LB라도 충돌 회피 위해 권장)
        if ! [[ "$N8N_PORT" =~ ^[0-9]+$ ]] || (( N8N_PORT < 1 || N8N_PORT > 65535 )); then
            log_error "--n8n-port가 유효하지 않습니다: $N8N_PORT"
            exit 1
        fi
    fi

    # Telegraf 인자 검증
    if [[ "$INSTALL_TELEGRAF" == "true" ]]; then
        case "$TELEGRAF_OUTPUT" in
            influxdb_v2)
                local missing=()
                [[ -z "$INFLUXDB_URL" ]]    && missing+=("--influxdb-url")
                [[ -z "$INFLUXDB_TOKEN" ]]  && missing+=("--influxdb-token")
                [[ -z "$INFLUXDB_ORG" ]]    && missing+=("--influxdb-org")
                [[ -z "$INFLUXDB_BUCKET" ]] && missing+=("--influxdb-bucket")
                if [[ ${#missing[@]} -gt 0 ]]; then
                    log_error "Telegraf influxdb_v2 출력에는 다음 인자가 필요합니다: ${missing[*]}"
                    exit 1
                fi
                ;;
            http)
                local missing=()
                [[ -z "$HTTP_URL" ]]             && missing+=("--http-url")
                [[ -z "$OAUTH2_TOKEN_URL" ]]     && missing+=("--oauth2-token-url")
                [[ -z "$OAUTH2_CLIENT_ID" ]]     && missing+=("--oauth2-client-id")
                [[ -z "$OAUTH2_CLIENT_SECRET" ]] && missing+=("--oauth2-client-secret")
                if [[ ${#missing[@]} -gt 0 ]]; then
                    log_error "Telegraf http(OAuth2) 출력에는 다음 인자가 필요합니다: ${missing[*]}"
                    exit 1
                fi
                ;;
            *)
                log_error "지원되지 않는 --telegraf-output: $TELEGRAF_OUTPUT (influxdb_v2 | http)"
                exit 1
                ;;
        esac
    fi

    # 기존 설치 감지
    if command -v k3s >/dev/null 2>&1; then
        log_warn "기존 k3s 설치가 감지되었습니다. 버전: $(k3s --version | head -n1)"
        read -r -p "계속 진행하시겠습니까? (재설치/업그레이드) [y/N]: " ans
        [[ "$ans" =~ ^[Yy]$ ]] || { log_info "사용자 취소"; exit 0; }
    fi

    log_ok "사전 점검 완료"
}

# ----------------------------------------------------------------------------
# 시스템 준비 (swap, br_netfilter, sysctl)
# ----------------------------------------------------------------------------
prepare_system() {
    log_info "시스템 환경 준비..."

    # swap off (k3s는 swap 사용 시 동작 가능하나 권장사항에 따라 비활성)
    if [[ $(swapon --show | wc -l) -gt 0 ]]; then
        log_info "swap 비활성화"
        swapoff -a || log_warn "swapoff 실패 (계속 진행)"
        sed -ri 's/^([^#].*\sswap\s.*)$/#\1/' /etc/fstab || true
    fi

    # 커널 모듈
    cat >/etc/modules-load.d/k3s.conf <<'EOF'
overlay
br_netfilter
EOF
    modprobe overlay || log_warn "overlay 모듈 로드 실패"
    modprobe br_netfilter || log_warn "br_netfilter 모듈 로드 실패"

    # sysctl
    cat >/etc/sysctl.d/99-k3s.conf <<'EOF'
net.bridge.bridge-nf-call-iptables  = 1
net.bridge.bridge-nf-call-ip6tables = 1
net.ipv4.ip_forward                 = 1
fs.inotify.max_user_instances       = 8192
fs.inotify.max_user_watches         = 524288
EOF
    sysctl --system >/dev/null

    log_ok "시스템 환경 준비 완료"
}

# ----------------------------------------------------------------------------
# 방화벽 설정 (선택)
# ----------------------------------------------------------------------------
configure_firewall() {
    if [[ "$SKIP_FIREWALL" == "true" ]]; then
        log_info "방화벽 설정 스킵"
        return
    fi

    if systemctl is-active --quiet firewalld; then
        log_info "firewalld 감지 - k3s 포트 허용"
        firewall-cmd --permanent --add-port=6443/tcp     # kube-api
        firewall-cmd --permanent --add-port=10250/tcp    # kubelet
        firewall-cmd --permanent --add-port=8472/udp     # flannel VXLAN
        firewall-cmd --permanent --add-port=2379-2380/tcp # etcd (HA)
        firewall-cmd --permanent --add-source=10.42.0.0/16 # pod CIDR
        firewall-cmd --permanent --add-source=10.43.0.0/16 # service CIDR
        # Traefik Ingress 표준 포트
        if [[ ",$DISABLE_COMPONENTS," != *",traefik,"* ]]; then
            firewall-cmd --permanent --add-port=80/tcp
            firewall-cmd --permanent --add-port=443/tcp
        fi
        # n8n LoadBalancer 포트
        if [[ "$INSTALL_N8N" == "true" ]]; then
            firewall-cmd --permanent --add-port=${N8N_PORT}/tcp
        fi
        firewall-cmd --reload
        log_ok "firewalld 규칙 적용 완료"
    elif command -v ufw >/dev/null 2>&1 && ufw status | grep -q "Status: active"; then
        log_info "ufw 감지 - k3s 포트 허용"
        ufw allow 6443/tcp
        ufw allow 10250/tcp
        ufw allow 8472/udp
        ufw allow from 10.42.0.0/16
        ufw allow from 10.43.0.0/16
        if [[ ",$DISABLE_COMPONENTS," != *",traefik,"* ]]; then
            ufw allow 80/tcp
            ufw allow 443/tcp
        fi
        if [[ "$INSTALL_N8N" == "true" ]]; then
            ufw allow "${N8N_PORT}/tcp"
        fi
        log_ok "ufw 규칙 적용 완료"
    else
        log_info "활성 방화벽 미감지 - 스킵"
    fi
}

# ----------------------------------------------------------------------------
# k3s 설치
# ----------------------------------------------------------------------------
install_k3s() {
    log_info "k3s 설치 시작 (mode=$NODE_MODE)"

    local install_env=()
    local install_args=()

    # 버전
    if [[ -n "$K3S_VERSION" ]]; then
        install_env+=("INSTALL_K3S_VERSION=$K3S_VERSION")
        log_info "지정 버전: $K3S_VERSION"
    else
        install_env+=("INSTALL_K3S_CHANNEL=stable")
        log_info "stable 채널 사용"
    fi

    # 데이터 디렉토리
    install_args+=("--data-dir=$DATA_DIR")

    # 컴포넌트 비활성화
    if [[ -n "$DISABLE_COMPONENTS" ]]; then
        IFS=',' read -ra components <<< "$DISABLE_COMPONENTS"
        for c in "${components[@]}"; do
            install_args+=("--disable=$c")
        done
        log_info "비활성화 컴포넌트: $DISABLE_COMPONENTS"
    fi

    # 모드별 분기
    if [[ "$NODE_MODE" == "server" ]]; then
        install_env+=("INSTALL_K3S_EXEC=server")

        # kubeconfig 권한 모드 (설치 시점에 적용)
        install_args+=("--write-kubeconfig-mode=$KUBECONFIG_MODE")
        log_info "kubeconfig mode: $KUBECONFIG_MODE"

        # TLS SAN: 사용자가 지정하지 않았으면 호스트 1차 IP 자동 추가
        if [[ ${#TLS_SANS[@]} -eq 0 ]]; then
            local primary_ip
            primary_ip=$(hostname -I | awk '{print $1}')
            if [[ -n "$primary_ip" ]]; then
                TLS_SANS+=("$primary_ip")
                log_info "TLS SAN 자동 추가 (device_ip): $primary_ip"
            fi
        fi
        for san in "${TLS_SANS[@]}"; do
            install_args+=("--tls-san=$san")
            log_info "TLS SAN 적용: $san"
        done

        if [[ "$CLUSTER_INIT" == "true" ]]; then
            install_args+=("--cluster-init")
            log_info "HA 클러스터 init 모드"
        fi
        if [[ -n "$JOIN_TOKEN" ]]; then
            install_env+=("K3S_TOKEN=$JOIN_TOKEN")
        fi
        if [[ -n "$SERVER_URL" ]]; then
            # 추가 server 노드가 기존 클러스터에 join
            install_env+=("K3S_URL=$SERVER_URL")
        fi
    else
        install_env+=("INSTALL_K3S_EXEC=agent")
        install_env+=("K3S_TOKEN=$JOIN_TOKEN")
        install_env+=("K3S_URL=$SERVER_URL")

        # agent 모드에 무관한 옵션 경고
        if [[ ${#TLS_SANS[@]} -gt 0 ]]; then
            log_warn "--tls-san은 server 모드 전용입니다. 무시됩니다."
        fi
    fi

    # 설치 스크립트 실행
    log_info "공식 인스톨러 다운로드 및 실행..."
    # shellcheck disable=SC2068
    curl -sfL https://get.k3s.io | env ${install_env[@]} sh -s - ${install_args[@]}

    log_ok "k3s 설치 완료"
}

# ----------------------------------------------------------------------------
# 설치 후 검증
# ----------------------------------------------------------------------------
post_install_verify() {
    log_info "설치 검증..."

    local svc_name
    svc_name=$([[ "$NODE_MODE" == "server" ]] && echo "k3s" || echo "k3s-agent")

    # 서비스 활성화 확인
    local retry=0
    until systemctl is-active --quiet "$svc_name"; do
        retry=$((retry + 1))
        if [[ $retry -gt 30 ]]; then
            log_error "$svc_name 서비스가 활성화되지 않았습니다."
            systemctl status "$svc_name" --no-pager || true
            exit 1
        fi
        sleep 2
    done
    log_ok "$svc_name 서비스 active"

    # server 모드: 노드 / 토큰 / kubeconfig 안내
    if [[ "$NODE_MODE" == "server" ]]; then
        # API 서버 응답 대기 (서비스 active 이후에도 API는 잠시 후 준비됨)
        log_info "API 서버 응답 대기..."
        retry=0
        until k3s kubectl get --raw=/readyz >/dev/null 2>&1; do
            retry=$((retry + 1))
            if [[ $retry -gt 90 ]]; then
                log_warn "API 서버가 아직 준비되지 않았습니다. (수동 확인 필요)"
                break
            fi
            sleep 2
        done

        # 노드 ready 대기
        log_info "노드 Ready 대기..."
        retry=0
        until k3s kubectl get nodes 2>/dev/null | grep -qw "Ready"; do
            retry=$((retry + 1))
            if [[ $retry -gt 90 ]]; then
                log_warn "노드가 아직 Ready 상태가 아닙니다. (수동 확인 필요)"
                break
            fi
            sleep 2
        done

        echo
        log_ok "==== 클러스터 정보 ===="
        k3s kubectl get nodes -o wide || true
        echo

        # kubeconfig 권한 안내 (server 인스톨러가 이미 적용했으나 보강)
        if [[ -f /etc/rancher/k3s/k3s.yaml ]]; then
            chmod "$KUBECONFIG_MODE" /etc/rancher/k3s/k3s.yaml
            log_info "kubeconfig: /etc/rancher/k3s/k3s.yaml (mode=$KUBECONFIG_MODE)"
            log_info "외부 사용: export KUBECONFIG=/etc/rancher/k3s/k3s.yaml"
        fi

        # join token 노출
        if [[ -f /var/lib/rancher/k3s/server/node-token ]]; then
            local token
            token=$(cat /var/lib/rancher/k3s/server/node-token)
            local ip
            ip=$(hostname -I | awk '{print $1}')
            echo
            log_ok "==== Agent Join 정보 ===="
            echo "    K3S_URL=https://${ip}:6443"
            echo "    K3S_TOKEN=${token}"
        fi
    else
        log_ok "agent 노드가 클러스터에 join되었습니다."
    fi
}

# ----------------------------------------------------------------------------
# API 접근 제어용 kubeconfig 발급 (ServiceAccount 토큰 기반)
#   - 외부 시스템(CI/CD, 컨트롤러, API 클라이언트)이 클러스터에 접근하기 위한 파일
#   - ServiceAccount + ClusterRoleBinding 생성 후 토큰으로 kubeconfig 작성
# ----------------------------------------------------------------------------
generate_api_kubeconfig() {
    if [[ "$GENERATE_KUBECONFIG" != "true" ]]; then
        return
    fi

    log_info "API 접근용 kubeconfig 발급 시작..."

    export KUBECONFIG=/etc/rancher/k3s/k3s.yaml

    # --- Step 1: ServiceAccount + ClusterRoleBinding 생성 ---
    log_info "Step 1: ServiceAccount '$KUBECONFIG_SA' (ns=$KUBECONFIG_SA_NAMESPACE) 준비..."
    if ! k3s kubectl get sa "$KUBECONFIG_SA" -n "$KUBECONFIG_SA_NAMESPACE" >/dev/null 2>&1; then
        k3s kubectl create sa "$KUBECONFIG_SA" -n "$KUBECONFIG_SA_NAMESPACE"
        log_ok "ServiceAccount 생성: $KUBECONFIG_SA_NAMESPACE/$KUBECONFIG_SA"
    else
        log_info "ServiceAccount 이미 존재함 (재사용)"
    fi

    local crb_name="${KUBECONFIG_SA}-binding"
    if ! k3s kubectl get clusterrolebinding "$crb_name" >/dev/null 2>&1; then
        k3s kubectl create clusterrolebinding "$crb_name" \
            --clusterrole="$KUBECONFIG_CLUSTER_ROLE" \
            --serviceaccount="${KUBECONFIG_SA_NAMESPACE}:${KUBECONFIG_SA}"
        log_ok "ClusterRoleBinding 생성: $crb_name (role=$KUBECONFIG_CLUSTER_ROLE)"
    else
        log_info "ClusterRoleBinding 이미 존재함 (재사용)"
    fi

    # cluster-admin이 아닌 경우 경고
    if [[ "$KUBECONFIG_CLUSTER_ROLE" != "cluster-admin" ]]; then
        log_info "주의: cluster-admin이 아닌 '$KUBECONFIG_CLUSTER_ROLE' 권한이 부여되었습니다."
    fi

    # --- Step 2: API server URL 결정 ---
    log_info "Step 2: API server URL 및 CA 추출..."
    local server=""
    if [[ -n "$KUBECONFIG_SERVER_URL" ]]; then
        server="$KUBECONFIG_SERVER_URL"
        log_info "외부 server URL 사용 (지정): $server"
    else
        # 우선순위:
        #   1) TLS_SANS의 도메인(첫 번째 비-IP 항목)
        #   2) TLS_SANS의 첫 항목
        #   3) 호스트 1차 IP
        local candidate=""
        if [[ ${#TLS_SANS[@]} -gt 0 ]]; then
            for s in "${TLS_SANS[@]}"; do
                if ! [[ "$s" =~ ^[0-9.]+$ ]]; then
                    candidate="$s"
                    break
                fi
            done
            [[ -z "$candidate" ]] && candidate="${TLS_SANS[0]}"
        fi
        if [[ -z "$candidate" ]]; then
            candidate=$(hostname -I | awk '{print $1}')
        fi
        server="https://${candidate}:6443"
        log_info "외부 server URL 자동 결정: $server"
    fi

    # CA 데이터 추출 (k3s.yaml의 cluster[0].cluster.certificate-authority-data)
    local ca_data
    ca_data=$(k3s kubectl config view --raw \
        -o jsonpath='{.clusters[0].cluster.certificate-authority-data}')
    if [[ -z "$ca_data" ]]; then
        log_error "CA 데이터 추출 실패"
        return 1
    fi

    # --- Step 3: 토큰 발급 ---
    log_info "Step 3: 토큰 발급 (duration=$KUBECONFIG_TOKEN_DURATION)..."
    local token
    token=$(k3s kubectl create token "$KUBECONFIG_SA" \
        -n "$KUBECONFIG_SA_NAMESPACE" \
        --duration="$KUBECONFIG_TOKEN_DURATION")
    if [[ -z "$token" ]]; then
        log_error "토큰 발급 실패"
        return 1
    fi
    log_ok "토큰 발급 완료 (${#token} chars)"

    # --- Step 4: kubeconfig 파일 작성 ---
    log_info "Step 4: kubeconfig 파일 작성: $KUBECONFIG_OUT"

    # 출력 디렉토리 보장
    local out_dir
    out_dir=$(dirname "$KUBECONFIG_OUT")
    mkdir -p "$out_dir"

    # 기존 파일 백업
    if [[ -f "$KUBECONFIG_OUT" ]]; then
        cp -a "$KUBECONFIG_OUT" "${KUBECONFIG_OUT}.bak.$(date +%Y%m%d-%H%M%S)"
        log_warn "기존 파일 백업: ${KUBECONFIG_OUT}.bak.*"
    fi

    cat >"$KUBECONFIG_OUT" <<EOF
apiVersion: v1
kind: Config
clusters:
- name: ${KUBECONFIG_CLUSTER_NAME}
  cluster:
    server: ${server}
    certificate-authority-data: ${ca_data}
users:
- name: ${KUBECONFIG_USER_NAME}
  user:
    token: ${token}
contexts:
- name: ${KUBECONFIG_CONTEXT_NAME}
  context:
    cluster: ${KUBECONFIG_CLUSTER_NAME}
    user: ${KUBECONFIG_USER_NAME}
current-context: ${KUBECONFIG_CONTEXT_NAME}
EOF

    chmod 600 "$KUBECONFIG_OUT"

    # --- Step 5: 검증 ---
    log_info "Step 5: 발급된 kubeconfig 검증..."
    if KUBECONFIG="$KUBECONFIG_OUT" k3s kubectl get --raw=/healthz >/dev/null 2>&1; then
        log_ok "kubeconfig 검증 성공 (API 도달 가능)"
    else
        log_warn "kubeconfig 검증 실패 - server URL/방화벽/SAN을 확인하세요"
        log_warn "  server: $server"
    fi

    echo
    log_ok "==== API 접근용 kubeconfig 발급 완료 ===="
    echo "    파일: $KUBECONFIG_OUT (mode=600)"
    echo "    ServiceAccount: ${KUBECONFIG_SA_NAMESPACE}/${KUBECONFIG_SA}"
    echo "    ClusterRole:    ${KUBECONFIG_CLUSTER_ROLE}"
    echo "    Server:         ${server}"
    echo "    Token 유효기간: ${KUBECONFIG_TOKEN_DURATION}"
    echo
    log_info "사용 예시:"
    log_info "  scp ${KUBECONFIG_OUT} <원격호스트>:~/.kube/config"
    log_info "  kubectl --kubeconfig=${KUBECONFIG_OUT} get nodes"
}

# ----------------------------------------------------------------------------
# Helm 설치 (없을 때만)
# ----------------------------------------------------------------------------
ensure_helm() {
    if command -v helm >/dev/null 2>&1; then
        log_info "helm 이미 설치됨: $(helm version --short 2>/dev/null || true)"
        return
    fi
    log_info "helm 설치 중..."
    curl -sfL https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
    log_ok "helm 설치 완료: $(helm version --short 2>/dev/null || true)"
}

# ----------------------------------------------------------------------------
# Telegraf Helm 차트 설치
#   - output 타입: influxdb_v2 | http (OAuth2 client_credentials)
# ----------------------------------------------------------------------------

# --- influxdb_v2 output용 Secret/Env 생성 ---
_build_telegraf_secret_influxdb() {
    local secret_name="$1"
    k3s kubectl -n "$TELEGRAF_NAMESPACE" delete secret "$secret_name" >/dev/null 2>&1 || true
    k3s kubectl -n "$TELEGRAF_NAMESPACE" create secret generic "$secret_name" \
        --from-literal=INFLUX_TOKEN="$INFLUXDB_TOKEN" >/dev/null
    log_info "InfluxDB token Secret 생성: $secret_name"
}

# --- http+OAuth2 output용 Secret 생성 (client_id/secret) ---
_build_telegraf_secret_oauth2() {
    local secret_name="$1"
    k3s kubectl -n "$TELEGRAF_NAMESPACE" delete secret "$secret_name" >/dev/null 2>&1 || true
    k3s kubectl -n "$TELEGRAF_NAMESPACE" create secret generic "$secret_name" \
        --from-literal=OAUTH2_CLIENT_ID="$OAUTH2_CLIENT_ID" \
        --from-literal=OAUTH2_CLIENT_SECRET="$OAUTH2_CLIENT_SECRET" >/dev/null
    log_info "OAuth2 credentials Secret 생성: $secret_name"
}

# --- values.yaml: influxdb_v2 ---
_write_values_influxdb() {
    local values_file="$1"
    local secret_name="$2"
    cat >"$values_file" <<EOF
# Telegraf Helm values (output: influxdb_v2) - auto-generated by install-k3s.sh
replicaCount: 1

env:
  - name: HOSTNAME
    valueFrom:
      fieldRef:
        fieldPath: spec.nodeName
  - name: INFLUX_TOKEN
    valueFrom:
      secretKeyRef:
        name: ${secret_name}
        key: INFLUX_TOKEN

config:
  agent:
    interval: "10s"
    round_interval: true
    metric_batch_size: 1000
    metric_buffer_limit: 10000
    collection_jitter: "0s"
    flush_interval: "10s"
    flush_jitter: "0s"
    precision: ""
    hostname: "\$HOSTNAME"
    omit_hostname: false

  outputs:
    - influxdb_v2:
        urls:
          - "${INFLUXDB_URL}"
        token: "\${INFLUX_TOKEN}"
        organization: "${INFLUXDB_ORG}"
        bucket: "${INFLUXDB_BUCKET}"

  inputs:
    - cpu:
        percpu: true
        totalcpu: true
        collect_cpu_time: false
        report_active: false
    - disk:
        ignore_fs:
          - tmpfs
          - devtmpfs
          - devfs
          - overlay
          - aufs
          - squashfs
    - diskio: {}
    - mem: {}
    - net: {}
    - system: {}
    - kernel: {}
    - processes: {}
    - swap: {}
EOF
}

# --- values.yaml: http + OAuth2 client_credentials ---
_write_values_http_oauth2() {
    local values_file="$1"
    local secret_name="$2"

    # scopes 변환: "a,b,c" -> ["a", "b", "c"]
    # http: 블록의 자식이므로 들여쓰기 8 spaces
    local scopes_yaml=""
    if [[ -n "$OAUTH2_SCOPES" ]]; then
        scopes_yaml="        scopes:"$'\n'
        IFS=',' read -ra _scopes <<< "$OAUTH2_SCOPES"
        for s in "${_scopes[@]}"; do
            # 앞뒤 공백 제거
            s="${s#"${s%%[![:space:]]*}"}"
            s="${s%"${s##*[![:space:]]}"}"
            scopes_yaml+="          - \"${s}\""$'\n'
        done
    fi

    # audience (선택)
    local audience_yaml=""
    if [[ -n "$OAUTH2_AUDIENCE" ]]; then
        audience_yaml="        audience: \"${OAUTH2_AUDIENCE}\""$'\n'
    fi

    # content_encoding (선택)
    local enc_yaml=""
    if [[ -n "$HTTP_CONTENT_ENCODING" ]]; then
        enc_yaml="        content_encoding: \"${HTTP_CONTENT_ENCODING}\""$'\n'
    fi

    cat >"$values_file" <<EOF
# Telegraf Helm values (output: http + OAuth2) - auto-generated by install-k3s.sh
replicaCount: 1

env:
  - name: HOSTNAME
    valueFrom:
      fieldRef:
        fieldPath: spec.nodeName
  - name: OAUTH2_CLIENT_ID
    valueFrom:
      secretKeyRef:
        name: ${secret_name}
        key: OAUTH2_CLIENT_ID
  - name: OAUTH2_CLIENT_SECRET
    valueFrom:
      secretKeyRef:
        name: ${secret_name}
        key: OAUTH2_CLIENT_SECRET

config:
  agent:
    interval: "10s"
    round_interval: true
    metric_batch_size: 1000
    metric_buffer_limit: 10000
    collection_jitter: "0s"
    flush_interval: "10s"
    flush_jitter: "0s"
    precision: ""
    hostname: "\$HOSTNAME"
    omit_hostname: false

  outputs:
    - http:
        url: "${HTTP_URL}"
        method: "${HTTP_METHOD}"
        timeout: "${HTTP_TIMEOUT}"
        data_format: "${HTTP_DATA_FORMAT}"
${enc_yaml}        # --- OAuth2 (client_credentials) ---
        # Telegraf http output 플러그인 내장 OAuth2 설정
        # 액세스 토큰은 만료 시 자동 갱신됨
        client_id: "\${OAUTH2_CLIENT_ID}"
        client_secret: "\${OAUTH2_CLIENT_SECRET}"
        token_url: "${OAUTH2_TOKEN_URL}"
${scopes_yaml}${audience_yaml}
  inputs:
    - cpu:
        percpu: true
        totalcpu: true
        collect_cpu_time: false
        report_active: false
    - disk:
        ignore_fs:
          - tmpfs
          - devtmpfs
          - devfs
          - overlay
          - aufs
          - squashfs
    - diskio: {}
    - mem: {}
    - net: {}
    - system: {}
    - kernel: {}
    - processes: {}
    - swap: {}
EOF
}

install_telegraf_chart() {
    if [[ "$INSTALL_TELEGRAF" != "true" ]]; then
        return
    fi

    log_info "Telegraf Helm 설치 시작 (output=$TELEGRAF_OUTPUT)"

    # kubeconfig 환경: k3s가 만든 파일을 helm/kubectl에 노출
    export KUBECONFIG=/etc/rancher/k3s/k3s.yaml

    ensure_helm

    # influxdata 레포 추가/업데이트
    helm repo add influxdata https://helm.influxdata.com/ >/dev/null 2>&1 || true
    helm repo update influxdata >/dev/null

    # namespace 보장
    if ! k3s kubectl get ns "$TELEGRAF_NAMESPACE" >/dev/null 2>&1; then
        k3s kubectl create namespace "$TELEGRAF_NAMESPACE"
        log_info "namespace 생성: $TELEGRAF_NAMESPACE"
    fi

    local values_file
    values_file=$(mktemp /tmp/telegraf-values-XXXXXX.yaml)
    local secret_name

    case "$TELEGRAF_OUTPUT" in
        influxdb_v2)
            secret_name="${TELEGRAF_RELEASE}-influxdb-token"
            _build_telegraf_secret_influxdb "$secret_name"
            _write_values_influxdb "$values_file" "$secret_name"
            ;;
        http)
            secret_name="${TELEGRAF_RELEASE}-oauth2"
            _build_telegraf_secret_oauth2 "$secret_name"
            _write_values_http_oauth2 "$values_file" "$secret_name"
            ;;
    esac

    log_info "values 파일 생성: $values_file"

    # helm upgrade --install (idempotent)
    helm upgrade --install "$TELEGRAF_RELEASE" influxdata/telegraf \
        --namespace "$TELEGRAF_NAMESPACE" \
        --values "$values_file" \
        --wait --timeout 5m

    rm -f "$values_file"

    echo
    log_ok "==== Telegraf 배포 상태 ===="
    k3s kubectl -n "$TELEGRAF_NAMESPACE" get pods -l "app.kubernetes.io/name=telegraf" || true
    echo
    log_info "로그 확인: kubectl -n $TELEGRAF_NAMESPACE logs -l app.kubernetes.io/name=telegraf --tail=50"
    case "$TELEGRAF_OUTPUT" in
        influxdb_v2)
            log_info "출력 대상: ${INFLUXDB_URL} (org=${INFLUXDB_ORG}, bucket=${INFLUXDB_BUCKET})"
            ;;
        http)
            log_info "출력 대상: ${HTTP_URL} (OAuth2 token endpoint=${OAUTH2_TOKEN_URL})"
            ;;
    esac
}

# ----------------------------------------------------------------------------
# n8n Helm 차트 설치 (8gears/n8n community chart, SQLite + PVC)
#   - Service: LoadBalancer, 외부 포트 = N8N_PORT (default 31000)
#   - Ingress: Traefik (HTTPS termination은 외부/wildcard 인증서 정책에 따름)
#   - iframe 임베드: Traefik middleware로 CSP frame-ancestors 주입
# ----------------------------------------------------------------------------

# CSP frame-ancestors 헤더 값 생성: "https://a.com https://b.com"
_n8n_csp_frame_ancestors() {
    if [[ -z "$N8N_IFRAME_ALLOW" ]]; then
        # 기본: self만 허용 (임베드 차단)
        echo "'self'"
        return
    fi
    local result=""
    IFS=',' read -ra _origins <<< "$N8N_IFRAME_ALLOW"
    for o in "${_origins[@]}"; do
        o="${o#"${o%%[![:space:]]*}"}"
        o="${o%"${o##*[![:space:]]}"}"
        result+="${o} "
    done
    # trailing space 제거
    echo "${result% }"
}

_write_values_n8n() {
    local values_file="$1"
    local csp_value="$2"

    # 외부 접근 URL (Traefik이 80/443 또는 N8N_PORT 둘 다 라우팅 가능)
    local proto="https"
    local webhook_url="${proto}://${N8N_HOST}/"

    # 8gears chart 핵심 규칙:
    #   main.config.<key>: <value>  →  ENV <KEY>=<value> 로 자동 변환
    #   예) main.config.n8n.host: "x"  →  N8N_HOST=x
    #       main.config.db.type: "sqlite" → DB_TYPE=sqlite
    # 참고: https://github.com/8gears/n8n-helm-chart README의 변환 규칙

    cat >"$values_file" <<EOF
# n8n Helm values (chart: 8gears/n8n-helm-chart 2.x via OCI)
# - auto-generated by install-k3s.sh
#
# 8gears chart 핵심 규칙:
#   main.config.<path>.<key>: <value>   →   ENV <PATH>_<KEY>=<value> 로 자동 변환
#   예) main.config.n8n.host: "x"        → N8N_HOST=x
#       main.config.n8n.webhook_url: "x" → N8N_WEBHOOK_URL=x
#       main.config.db.type: "sqlite"    → DB_TYPE=sqlite
# 참고: https://github.com/8gears/n8n-helm-chart README

image:
  repository: n8nio/n8n
  pullPolicy: IfNotPresent

main:
  replicaCount: 1
  deploymentStrategy:
    type: Recreate

  # n8n config (1:1 ENV 변환됨)
  config:
    n8n:
      host: "${N8N_HOST}"
      protocol: "${proto}"
      port: 5678
      editor_base_url: "${webhook_url}"
      webhook_url: "${webhook_url}"
EOF

    # iframe 임베드 환경에서 cookie SameSite 제약 회피 (N8N_SECURE_COOKIE=false)
    # 들여쓰기: main.config.n8n 의 자식이어야 N8N_SECURE_COOKIE 로 변환됨
    if [[ "$N8N_INSECURE_COOKIE" == "true" ]]; then
        cat >>"$values_file" <<EOF
      secure_cookie: false
EOF
    fi

    cat >>"$values_file" <<EOF
    db:
      type: "sqlite"

  # PVC (SQLite 데이터 보존)
  persistence:
    enabled: true
    type: "dynamic"
    mountPath: "/home/node/.n8n"
    storageClass: "${N8N_STORAGE_CLASS}"
    size: "${N8N_STORAGE_SIZE}"
    accessModes:
      - ReadWriteOnce

  # 리소스 (개발/소규모 기본값)
  resources:
    requests:
      cpu: 100m
      memory: 256Mi
    limits:
      cpu: 1000m
      memory: 1Gi

  # 외부 노출 Service (8gears chart는 main.service 위치를 읽음)
  service:
    type: LoadBalancer
    port: ${N8N_PORT}
    annotations: {}

# Ingress (Traefik)
ingress:
  enabled: true
  className: "traefik"
EOF

    # iframe Middleware가 정상 적용된 경우에만 annotation 부착
    # (없는 middleware를 참조하면 Traefik 라우팅이 503으로 깨질 수 있음)
    if [[ "$N8N_MIDDLEWARE_READY" == "true" ]]; then
        cat >>"$values_file" <<EOF
  annotations:
    traefik.ingress.kubernetes.io/router.middlewares: "${N8N_NAMESPACE}-${N8N_RELEASE}-iframe@kubernetescrd"
EOF
    else
        cat >>"$values_file" <<EOF
  annotations: {}
EOF
    fi

    cat >>"$values_file" <<EOF
  hosts:
    - host: "${N8N_HOST}"
      paths:
        - path: /
          pathType: Prefix
  tls: []

# Worker / webhook 별도 분리는 SQLite 모드에선 사용 안 함 (DB lock 이슈)
worker:
  enabled: false
webhook:
  enabled: false

# Valkey/Redis는 queue mode에서만 필요. SQLite + 단일 인스턴스에선 불필요
valkey:
  enabled: false
EOF
}

# ----------------------------------------------------------------------------
# Traefik 배포 완료 대기 (k3s 초기 설치 시 Traefik이 늦게 뜨는 문제 해결)
#   - k3s는 Traefik을 helm-install-traefik Job + Deployment로 배포함
#   - 노드가 Ready여도 Traefik과 그 CRD(Middleware)는 그 직후에 등록됨
# ----------------------------------------------------------------------------
wait_for_traefik() {
    log_info "Traefik 배포 완료 대기..."

    local retry=0
    local max_retry=90   # 최대 약 3분 (2초 * 90)

    # 0) API 서버 응답성 먼저 확인 (connection refused 방지)
    #    install_k3s 직후 API 서버가 잠깐 불안정할 수 있으므로 먼저 대기
    retry=0
    local api_ok="false"
    while [[ $retry -lt 60 ]]; do
        if k3s kubectl get --raw=/readyz >/dev/null 2>&1; then
            api_ok="true"
            break
        fi
        retry=$((retry + 1))
        sleep 2
    done
    if [[ "$api_ok" != "true" ]]; then
        log_warn "k3s API 서버에 접속할 수 없습니다 (127.0.0.1:6443)."
        log_warn "  k3s 서비스 상태를 확인하세요: systemctl status k3s"
        log_warn "  Traefik 대기를 건너뜁니다."
        return 0
    fi

    # traefik이 비활성화된 경우 (방어적 체크)
    if [[ ",$DISABLE_COMPONENTS," == *",traefik,"* ]]; then
        log_info "Traefik 비활성화 상태 - 대기 건너뜀"
        return 0
    fi

    # 1) helm-install-traefik Job 완료 대기 (존재하는 경우)
    retry=0
    while [[ $retry -lt $max_retry ]]; do
        # Job이 아직 생성도 안 됐을 수 있으므로 존재 여부부터 확인
        if k3s kubectl -n kube-system get job helm-install-traefik >/dev/null 2>&1; then
            local succeeded
            succeeded=$(k3s kubectl -n kube-system get job helm-install-traefik \
                -o jsonpath='{.status.succeeded}' 2>/dev/null || echo "")
            if [[ "$succeeded" == "1" ]]; then
                log_info "helm-install-traefik Job 완료"
                break
            fi
        fi
        retry=$((retry + 1))
        sleep 2
    done

    # 2) Traefik Deployment가 Available 상태가 될 때까지 대기
    retry=0
    while [[ $retry -lt $max_retry ]]; do
        if k3s kubectl -n kube-system get deploy traefik >/dev/null 2>&1; then
            # rollout 완료 확인
            if k3s kubectl -n kube-system rollout status deploy/traefik \
                --timeout=10s >/dev/null 2>&1; then
                log_ok "Traefik Deployment 준비 완료"
                return 0
            fi
        fi
        retry=$((retry + 1))
        sleep 2
    done

    log_warn "Traefik 준비 확인 타임아웃 (계속 진행하되 Middleware 적용이 실패할 수 있음)"
    return 0
}

install_n8n_chart() {
    if [[ "$INSTALL_N8N" != "true" ]]; then
        return
    fi

    log_info "n8n Helm 설치 시작 (host=$N8N_HOST, port=$N8N_PORT)"

    export KUBECONFIG=/etc/rancher/k3s/k3s.yaml
    ensure_helm

    # 8gears n8n chart는 OCI 레지스트리로만 배포됨 (https helm repo 형식 미지원)
    #   참고: https://github.com/8gears/n8n-helm-chart
    #   사용법: helm install <release> oci://8gears.container-registry.com/library/n8n
    local n8n_chart_ref="oci://8gears.container-registry.com/library/n8n"
    log_info "n8n chart: $n8n_chart_ref"

    # namespace
    if ! k3s kubectl get ns "$N8N_NAMESPACE" >/dev/null 2>&1; then
        k3s kubectl create namespace "$N8N_NAMESPACE"
        log_info "namespace 생성: $N8N_NAMESPACE"
    fi

    # 초기 설치 시 Traefik이 아직 안 떴을 수 있으므로 명시적으로 대기
    wait_for_traefik

    # ---------- Traefik Middleware: iframe (CSP frame-ancestors) ----------
    local csp
    csp=$(_n8n_csp_frame_ancestors)
    log_info "CSP frame-ancestors: $csp"

    # Traefik Middleware CRD의 API 그룹은 Traefik 버전에 따라 다름:
    #   - 신버전(Traefik v2.10+/v3): traefik.io/v1alpha1
    #   - 구버전:                    traefik.containo.us/v1alpha1
    # 설치된 CRD를 조회해 올바른 API 그룹을 자동 선택.
    local mw_apiversion=""
    # CRD가 등록될 때까지 대기 (wait_for_traefik 이후에도 CRD 등록엔 약간 지연 가능)
    local retry=0
    while [[ $retry -lt 60 ]]; do
        if k3s kubectl get crd middlewares.traefik.io >/dev/null 2>&1; then
            mw_apiversion="traefik.io/v1alpha1"
            break
        elif k3s kubectl get crd middlewares.traefik.containo.us >/dev/null 2>&1; then
            mw_apiversion="traefik.containo.us/v1alpha1"
            break
        fi
        retry=$((retry + 1))
        sleep 2
    done

    if [[ -z "$mw_apiversion" ]]; then
        log_warn "Traefik Middleware CRD를 찾을 수 없습니다. iframe 임베드 설정을 건너뜁니다."
        log_warn "  Traefik이 비활성화되었거나 아직 준비되지 않았을 수 있습니다."
        log_warn "  수동 확인: kubectl get crd | grep middlewares"
        N8N_MIDDLEWARE_READY="false"
    else
        log_info "Traefik Middleware API 그룹: $mw_apiversion"
        local mw_file
        mw_file=$(mktemp /tmp/n8n-middleware-XXXXXX.yaml)
        # X-Frame-Options는 deprecated이고 frame-ancestors가 우선되므로 CSP만 사용.
        # 단, 일부 구형 브라우저 호환을 위해 X-Frame-Options를 제거.
        cat >"$mw_file" <<EOF
apiVersion: ${mw_apiversion}
kind: Middleware
metadata:
  name: ${N8N_RELEASE}-iframe
  namespace: ${N8N_NAMESPACE}
spec:
  headers:
    # CSP frame-ancestors로 iframe 임베드 허용 도메인 지정
    contentSecurityPolicy: "frame-ancestors ${csp};"
    # n8n 응답에 X-Frame-Options: DENY가 박혀 들어오면 frame-ancestors가 무시되므로 제거
    customResponseHeaders:
      X-Frame-Options: ""
EOF
        # apply 재시도 (CRD 등록 직후 API aggregation이 잠깐 미준비일 수 있음)
        local apply_ok="false"
        local apply_try=0
        while [[ $apply_try -lt 5 ]]; do
            if k3s kubectl apply -f "$mw_file" >/dev/null 2>&1; then
                apply_ok="true"
                break
            fi
            apply_try=$((apply_try + 1))
            sleep 3
        done

        if [[ "$apply_ok" == "true" ]]; then
            log_ok "Traefik Middleware 적용: ${N8N_NAMESPACE}/${N8N_RELEASE}-iframe"
            N8N_MIDDLEWARE_READY="true"
        else
            log_warn "Middleware 적용 실패 (${apply_try}회 시도). iframe 임베드 없이 진행합니다."
            N8N_MIDDLEWARE_READY="false"
        fi
        rm -f "$mw_file"
    fi

    # ---------- Helm install ----------
    local values_file
    values_file=$(mktemp /tmp/n8n-values-XXXXXX.yaml)
    _write_values_n8n "$values_file" "$csp"
    log_info "values 파일 생성: $values_file"

    helm upgrade --install "$N8N_RELEASE" "$n8n_chart_ref" \
        --namespace "$N8N_NAMESPACE" \
        --values "$values_file" \
        --wait --timeout 5m || {
            log_warn "helm wait 타임아웃. 상태 확인 후 수동 점검 권장."
        }

    rm -f "$values_file"

    echo
    log_ok "==== n8n 배포 상태 ===="
    k3s kubectl -n "$N8N_NAMESPACE" get pods,svc,ingress
    echo

    local node_ip
    node_ip=$(hostname -I | awk '{print $1}')
    log_info "외부 접근: http(s)://${N8N_HOST}/  (DNS가 ${node_ip}으로 해석되어야 함)"
    log_info "직접 포트 접근: http://${node_ip}:${N8N_PORT}/  (Service LB 포트)"
    if [[ -n "$N8N_IFRAME_ALLOW" ]]; then
        log_info "iframe 임베드 허용: $N8N_IFRAME_ALLOW"
        if [[ "$N8N_INSECURE_COOKIE" != "true" ]]; then
            log_warn "HTTPS 사이트에서 HTTP n8n을 임베드하면 secure cookie로 인해 세션 유지가 실패할 수 있습니다."
            log_warn "  → n8n도 HTTPS로 노출하거나, HTTP 환경이라면 --n8n-insecure-cookie 옵션을 사용하세요."
        fi
    else
        log_info "iframe 임베드: 차단 ('self'만 허용)"
    fi
}

# ----------------------------------------------------------------------------
# main
# ----------------------------------------------------------------------------
main() {
    log_info "======== k3s 설치 스크립트 시작 ========"
    preflight_checks
    prepare_system
    configure_firewall
    install_k3s
    post_install_verify
    generate_api_kubeconfig
    install_telegraf_chart
    install_n8n_chart
    log_ok "======== 모든 단계 완료 ========"
}

main "$@"
